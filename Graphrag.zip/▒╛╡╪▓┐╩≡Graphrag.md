## 本地部署Graphrag

### 1.下载ollama

[Ollama](https://ollama.com/)

### 2.powershell

```
ollama pull llama3.2
ollama pull nomic-embed-text
```

### 3.下载Anaconda

[清华源下载windows（x86_64）最新版](https://mirrors.tuna.tsinghua.edu.cn/anaconda/)

### 4.创建环境： Anaconda打开Anaconda Powershell Prompt

```
conda create -n Graphrag1 python=3.12
```

之后按`enter`执行，直到完毕

`Graphrag1`为自己起的名字，可在目录`D:\anaconda\envs`中找到

```
conda activate Graphrag1
```

### 5.开始微软pipeline

#### 5-1 安装graphrag包

```
pip install graphrag
```

可在`D:\anaconda\envs\Graphrag1\Lib\site-packages`中找到`graphrag`

#### 5-2 创建用于测试的索引文件

在一个方便自己寻找的盘符中创建`graphragtest1`文件夹，在Anaconda Powershell Prompt中切换到此目录

```
cd E:
cd .\graphragtest1\
mkdir -p ./ragtest/input
```

在input中放入book.txt文件

初始化环境变量

```
 python -m graphrag.index --init --root ./ragtest
```

并修改`E:\graphragtest1\ragtest\prompts\community_report.txt`

`D:\anaconda\envs\Graphrag1\Lib\site-packages\graphrag\query\llm\oai\embedding.py`

`D:\anaconda\envs\Graphrag1\Lib\site-packages\graphrag\llm\openai\openai_embeddings_llm.py`

`E:\graphragtest1\ragtest\settings.yaml`

`settings.yaml`中的`model: llama3.2`、`model: nomic-embed-text`需要根据自己选择的模型进行更改

文件见压缩包`替换文件.zip`

#### 5-3 安装ollama

因为`graphrag`需要与`ollama`的`API`相交互

```
 pip install ollama
```

#### 5-4 测试运行

```
python -m graphrag.index --root ./ragtest
```

#### 5-5 全局查询与局部查询

```
python -m graphrag.query --root ./ragtest --method global "What are the top themes in this story"
```

```
python -m graphrag.query --root ./ragtest --method local "Who is Scrooge, and what are his main relationships?"
```

## 6.退出环境

```
conda deactivate
```

